#include<iostream>
#include <map>
#include <vector>
#include <utility> 

#include <cstdio>

using namespace std;

const int MAX_N = 20;

int N, K;
int grid[MAX_N + 1][MAX_N + 1];
int Answers[MAX_N + 1];

// class Block
// {
//     int type;
//     std::vector<int,int> neighbours;
// };

typedef map<int, vector<pair<int,int > >* > mapBlocks;

int find_block(int g[MAX_N + 1][MAX_N + 1], int i, int j, mapBlocks* mapka) ;
int move_down(int idx, mapBlocks *mapka, int N);

int main(int argc, char** argv)
{
        int test_case;
        /*
                freopen function below opens input.txt file in read only mode, and afterward,
                the program will read from input.txt file instead of standard(keyboard) input.
                To test your program, you may save input data in input.txt file,
                and use freopen function to read from the file when using cin function.
                You may remove the comment symbols(//) in the below statement and use it.
                Use #include<cstdio> or #include<stdio.h> to use the function in your program.
                But before submission, you must remove the freopen function or rewrite comment symbols(//).
        */
        freopen("input.txt", "r", stdin);
        
        
        /*
                Your program should handle 10 test cases given.
        */
        for(test_case = 1; test_case <= 10; ++test_case)
        {
                int i, j;
                /*
                        Read each test case from standard input.
                        The size of matirx is stored in 'N' and the total number of blocks is stored in 'K'.
                        After, the shape of the matrix is stored in the array 'grid'.
                        For example, if there is no block in the cell(2, 3), grid[2][3] has a value 0.
                        On the other hand, if there is a block 'K' in the cell (2,3), grid[2][3] has a value 'K'.
                */
                cin >> N >> K;

                for (i = 1; i <= N; i++)
                {
                        for (j = 1; j <= N; j++)
                        {
                                cin >> grid[i][j];
                        }
                }
                /////////////////////////////////////////////////////////////////////////////////////////////
                /*
                        Implement your algorithm here.
                        Assume your answer, a sequnce of N numbers, is stored in an array 'Answers'.
                */
                mapBlocks* map = new mapBlocks;
                //map.clear();
                for(i = N; i>=1; i--)
                {
                    for(j = N; j>=1; j--)
                    {
                        if(test_case == 1)
                        {
                            find_block(grid, i, j, map);
                        }
                    }
                }
                
                
                for( mapBlocks::iterator it=map->begin();it!=map->end();it++)
                {
                    pair<int, vector<pair<int,int> >* > p = (*it);
                    cout<< p.first<<endl;
                     
                    vector<pair<int,int> >* v = p.second; 
                    for(vector<pair<int,int> >::iterator itv=v->begin();itv!=v->end();itv++)
                    {
                         cout<< "\t [ "<<(*itv).first<<" , "<<(*itv).second<<" ]"<<endl;
                    }
                    move_down(p.first,map,N);
                }
                
                /////////////////////////////////////////////////////////////////////////////////////////////

                for (i = 1; i <= N; i++) Answers[i] = -1;

                // Print the answer to standard output(screen). 
                cout << "#" << test_case;
                for (i = 1; i <= N; i++) cout << " " << Answers[i];
                cout << endl;
        }

        return 0;//Your program should return 0 on normal termination.
}

int find_block(int g[MAX_N + 1][MAX_N + 1], int i, int j, mapBlocks *mapka) 
{
    if(g[i][j] != 0)
    {
        int &block_nr = g[i][j];
        cout<<"-- ["<<i<< " , " <<j<<" ] "<<block_nr<<endl;
        
        if(mapka->find(block_nr) == mapka->end())
        {
            vector<pair<int,int> > *block_items = new vector<pair<int,int> >;
            pair<int,int> p = make_pair<int,int>(i,j);
        
            block_items->push_back(p);
    
        
            ////////////////////////////////////////////////////////////////////////
            /// Horizoontally
            ////////////////////////////////////////////////////////////////////////
            // j+1 
            if(g[i][j+1] == block_nr && j<N)
            {
                block_items->push_back(make_pair<int,int>(i,j+1));
                
                if(g[i+1][j+1] == block_nr && j<N && i<N)
                {
                    block_items->push_back(make_pair<int,int>(i+1,j+1));
                    block_items->push_back(make_pair<int,int>(i+1,j));
                }
                else if(g[i-1][j+1] == block_nr && j<N && i>0)
                {
                    block_items->push_back(make_pair<int,int>(i-1,j+1));
                    block_items->push_back(make_pair<int,int>(i-1,j));
                }
            }
            
            // j-1
            if(g[i][j-1] == block_nr && j>0)
            {
                block_items->push_back(make_pair<int,int>(i,j-1));
                
                if(g[i+1][j-1] == block_nr && j>0 && i<N) // j>0 cond no needed
                {
                    block_items->push_back(make_pair<int,int>(i+1,j-1));
                    block_items->push_back(make_pair<int,int>(i+1,j));
                }
                else if(g[i-1][j-1] == block_nr && j>0 && i>0)
                {
                    block_items->push_back(make_pair<int,int>(i-1,j-1));
                    block_items->push_back(make_pair<int,int>(i-1,j));
                }
            }
            ////////////////////////////////////////////////////////////////////////
            /// Vertically
            ////////////////////////////////////////////////////////////////////////
            // i+1 
            if(g[i+1][j] == block_nr && i<N)
            {
                block_items->push_back(make_pair<int,int>(i+1,j));
                
                if(g[i+1][j+1] == block_nr && j<N && i<N)
                {
                    block_items->push_back(make_pair<int,int>(i+1,j+1));
                    block_items->push_back(make_pair<int,int>(i,j+1));
                }
                else if(g[i+1][j-1] == block_nr && j>0 && i<N)
                {
                    block_items->push_back(make_pair<int,int>(i+1,j-1));
                    block_items->push_back(make_pair<int,int>(i,j-1));
                }
            }
            
            // i-1
            if(g[i-1][j] == block_nr && i>0)
            {
                block_items->push_back(make_pair<int,int>(i-1,j));
                
                if(g[i-1][j+1] == block_nr && i>0 && j<N) // j>0 cond no needed
                {
                    block_items->push_back(make_pair<int,int>(i-1,j+1));
                    block_items->push_back(make_pair<int,int>(i,j+1));
                }
                else if(g[i-1][j-1] == block_nr && j>0 && i>0)
                {
                    block_items->push_back(make_pair<int,int>(i-1,j-1));
                    block_items->push_back(make_pair<int,int>(i,j-1));
                }
            }
            mapka->insert(make_pair(block_nr, block_items));
        }
    }
    
    return 0;
}

int move_down(int idx, mapBlocks *mapka, int N)
{
    mapBlocks::iterator it = mapka->find(idx);
    if(it == mapka->end())
        return -1;
    
    int res = 0;
    
    pair<int, vector<pair<int,int> >* > p = (*it);
    cout<< p.first<<endl;
    vector<pair<int,int> >* v = p.second;
     
    for(vector<pair<int,int> >::iterator it=v->begin();it!=v->end();it++)
    {
        pair<int,int> p =  (*it);
        cout<<(*it).first<<","<<(*it).second<<endl;
        int i = (*it).first;
        int j = (*it).second;
        if(i<N)
        {
            res++;
        }
    }
    if(v->size()==res)
    {
        cout<<"OK down"<<endl;
        
        for(vector<pair<int,int> >::iterator it=v->begin();it!=v->end();it++)
        {
            pair<int,int> p =  (*it);
            (*it).first = (*it).first+1;
        }    
        
        return 0;
    }
    
    
    return -1;
}

// int check_neighbours(int i, int j, int block_nr)
// {
//     if((g[i][j+1] == block_nr && j<N))
//     {
//     }
//     else
//     {
//     }
//     
//     if((g[i][j+1] == block_nr && j<N))
//     {
//     }
//     if((g[i][j+1] == block_nr && j<N))
//     {
//     }
//     if((g[i][j+1] == block_nr && j<N))
//     {
//     }
// }